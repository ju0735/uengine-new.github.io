-- 출퇴근 테이블
CREATE TABLE TPJ_ATTENDANCE (
    ATT_KEY     VARCHAR2(50) PRIMARY KEY,  -- 출퇴근키
    EMP_KEY     VARCHAR2(10),              -- 직원키
    WORK_DATE   DATE,                      -- 근무일자
    STATUS      VARCHAR2(2)  NOT NULL,     -- 상태(NM:정상/AB:결근)
    UNIQUE (EMP_KEY, WORK_DATE)
);