-- 급여 테이블
CREATE TABLE tpj_salary (
    sal_key     UUID PRIMARY KEY,         -- 급여키 (UUID 타입 사용)
    emp_key     VARCHAR(10),              -- 직원키
    pay_date    DATE NOT NULL,            -- 지급일자
    amount      NUMERIC(10) NOT NULL,     -- 지급액
    UNIQUE (emp_key, pay_date)
);